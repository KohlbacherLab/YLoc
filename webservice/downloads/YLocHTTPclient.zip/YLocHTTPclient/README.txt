YLoc - Interpretable Subcellular Localization Prediction - HTTP client
######################################################################

Usage: python yloc.py <fastafile.fasta> <model_name> <origin> <use of homology(Yes/No)> <output(Advanced/Simple)>

Available models: YLoc-LowRes, YLow-HighRes, YLoc+
Available origins: Animals, Fungi, Plants

Example:
--------
python yloc.py test.fasta YLoc-LowRes Animals Yes Simple


If you use the HTTP client to call YLoc, make sure that your internet connection is not blocked!

If you face any troubles, please contact us. Information can be found on the YLoc website: www.multiloc.org/YLoc.